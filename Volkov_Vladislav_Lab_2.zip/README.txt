Файлы формата .cpp содержат исключительно сами алгоритмы, 
одноименные с ними txt файлы содержат тот же код в текстовом виде:
Lab_2_algorithm_on_map.cpp
Lab_2_algorithm_on_map.txt
Lab_2_algorithm_on_tree.cpp
Lab_2_algorithm_on_tree.txt
Lab_2_brute_force_algorithm.cpp
Lab_2_brute_force_algorithm.txt

Следующие файлы содержат код, используемый для подсчета затрачиваемого времени на тестах:
Algorithm_on_map(for test).txt
Algorithm_on_tree(for test).txt
Brute_force(for test).txt

Файл Graphs_of_results.xlsx содержит таблицу и графики полученных результатов
